{{ ucfunc("put_docready_start") }}

  var objGallery = jQuery("#{{uc_id}}");  

  var api = objGallery.unitegallery({
    gallery_theme: "slider",
    gallery_width:'{{gallery_width_nounit}}%',							
    gallery_height:{{gallery_height_nounit}},		
    gallery_min_width: 100,						
    gallery_min_height: 300,					
    gallery_skin:"default",						
    gallery_images_preload_type:"minimal",		
    
    gallery_autoplay:{{gallery_autoplay}},						
    gallery_play_interval: {{gallery_play_interval}},			
    gallery_pause_on_mouseover: {{gallery_pause_on_mouseover}},	
    
    gallery_control_keyboard: {{gallery_control_keyboard}},				
    gallery_carousel:{{gallery_carousel}},						
    
    gallery_preserve_ratio: {{gallery_preserve_ratio}},		
    gallery_height_tablet:{{gallery_height_tablet_nounit}},                                
    gallery_height_mobile:{{gallery_height_mobile_nounit}},	    	                                
    gallery_debug_errors:true,					
    slider_background_color:"{{slider_background_color}}",
    
    //slider options: 
    slider_video_autoplay:{{video_autoplay}},
    slider_video_muted: {{mute_video}},                
    slider_scale_mode: "{{slider_scale_mode}}",									
    slider_scale_mode_media: "fill",			
    slider_scale_mode_fullscreen: "down",		
    slider_item_padding_top: 0,					
    slider_item_padding_bottom: 0,				
    slider_item_padding_left: 0,				
    slider_item_padding_right: 0,				
    
    slider_transition: "{{slider_transition}}",					
    slider_transition_speed:{{slider_transition_speed}},		
    slider_transition_easing: "easeInOutQuad",
    
    slider_control_swipe:{{slider_control_swipe}},					
    slider_control_zoom:{{slider_control_zoom}},					
    slider_zoom_max_ratio: {{slider_zoom_max_ratio}},				
    slider_loader_type: {{slider_loader_type}},						
    slider_loader_color:"white",
    
    slider_enable_bullets: {{slider_enable_bullets}},				
    slider_bullets_skin: "",					
    slider_bullets_space_between: {{slider_bullets_space_between}},			
    slider_bullets_align_hor:"{{slider_bullets_align_hor}}",			
    slider_bullets_align_vert:"{{slider_bullets_align_vert}}",			
    slider_bullets_offset_hor:{{slider_bullets_offset_hor}},			
    slider_bullets_offset_vert:{{slider_bullets_offset_vert}},				
    
    slider_enable_arrows: {{slider_enable_arrows}},					
    slider_arrows_skin: "",	
    slider_arrows_type: "{{arrows_icon_type}}",    //default / custom
    slider_arrows_custom_icon_right: "{{arrow_icon_right_html|ucsafe|raw}}", //custom arrow icon html
    slider_arrows_custom_icon_left: "{{arrow_icon_left_html|ucsafe|raw}}", //custom arrow icon html                
    slider_arrow_left_align_hor:"left",	  		
    slider_arrow_left_align_vert:"{{slider_arrow_align_vert}}", 	
    slider_arrow_left_offset_hor:{{arrow_horizontal_offset}},		  	
    slider_arrow_left_offset_vert:{{arrow_offset_vertical}},		 
    slider_arrow_right_align_hor:"right",   	
    slider_arrow_right_align_vert:"{{slider_arrow_align_vert}}", 	
    slider_arrow_right_offset_hor:{{arrow_horizontal_offset}},	   		
    slider_arrow_right_offset_vert:{{arrow_offset_vertical}},	   	
    
    slider_enable_progress_indicator: {{slider_enable_progress_indicator}},		 
    slider_progress_indicator_type: "{{slider_progress_indicator_type}}",		 
    slider_progress_indicator_align_hor:"{{slider_progress_indicator_align_hor}}",  
    slider_progress_indicator_align_vert:"{{slider_progress_indicator_align_vert}}",  
    slider_progress_indicator_offset_hor:{{slider_progress_indicator_offset_hor}},	
    slider_progress_indicator_offset_vert:{{slider_progress_indicator_offset_vert}},	
    slider_progressbar_color:"{{slider_progressbar_color}}",			
    slider_progressbar_opacity: {{slider_progressbar_opacity_nounit}},			
    slider_progressbar_line_width: {{slider_progressbar_line_width_nounit}},			 
    slider_progresspie_type_fill: false,		
    slider_progresspie_color1: "{{slider_progresspie_color1}}", 	
    slider_progresspie_stroke_width: {{progress_pie_stroke_width_nounit}},			
    slider_progresspie_width: {{progress_pie_size_nounit}},				
    slider_progresspie_height:{{progress_pie_size_nounit}},				 
    
    slider_enable_play_button: {{slider_enable_play_button}},			 
    slider_play_button_skin: "",				
    slider_play_button_align_hor:"{{slider_play_button_align_hor}}",    	
    slider_play_button_align_vert:"{{slider_play_button_align_vert}}",       
    slider_play_button_offset_hor:{{slider_play_button_offset_hor}},	       	 
    slider_play_button_offset_vert:{{slider_play_button_offset_vert}},	  
    slider_play_button_type: "{{play_button_icon_type}}",          //play button type - default, custom
    slider_play_button_custom: "{{custom_play_button_icon_html|ucsafe|raw}}",          //play button icon custom
    slider_pause_button_custom: "{{custom_pause_button_icon_html|ucsafe|raw}}",          //pause button icon custom                
    
    slider_enable_fullscreen_button: {{slider_enable_fullscreen_button}},		
    slider_fullscreen_button_skin: "",			
    slider_fullscreen_button_align_hor:"{{slider_fullscreen_button_align_hor}}",   
    slider_fullscreen_button_align_vert:"{{slider_fullscreen_button_align_vert}}",   
    slider_fullscreen_button_offset_hor:{{slider_fullscreen_button_offset_hor}},	   
    slider_fullscreen_button_offset_vert:{{slider_fullscreen_button_offset_vert}},	 
    slider_fullscreen_button_type: "{{fullscreen_button_type}}",    //fullscreen icon type: custom / default
    slider_fullscreen_button_icon_custom: "{{fullscreen_button_icon_html|ucsafe|raw}}",    //custom fullscreen icon html
    slider_smallscreen_button_icon_custom: "{{smallscreen_button_icon_html|ucsafe|raw}}",    //custom small icon html                
    
    slider_enable_zoom_panel: {{slider_enable_zoom_panel}},				 
    slider_zoompanel_skin: "",					 	  
    slider_zoompanel_align_hor:"{{slider_zoompanel_align_hor}}",    		
    slider_zoompanel_align_vert:"{{slider_zoompanel_align_vert}}",     	 	
    slider_zoompanel_offset_hor:{{slider_zoompanel_offset_hor}},	       	
    slider_zoompanel_offset_vert:{{slider_zoompanel_offset_vert}},	
    slider_zoom_icons_color: "{{zoom_icons_color}}",  
    slider_zoom_icons_type: "{{zoom_icons_type}}", // default / custom
    slider_zoom_icon_plus: "{{zoom_plus_icon_html|ucsafe|raw}}",  //custom plus icon html
    slider_zoom_icon_minus: "{{zoom_minus_icon_html|ucsafe|raw}}",  //custom minus icon html
    slider_zoom_icon_return: "{{zoom_return_icon_html|ucsafe|raw}}",  //custom return icon html               
    slider_controls_always_on: true,		     
    slider_controls_appear_ontap: true,			 
    slider_controls_appear_duration: 300,		 
    slider_videoplay_button_type: "square",	
    slider_videoplay_icon_type: "{{play_video_button_type}}",		//default, custom - the videoplay icon type
    slider_videoplay_icon_custom: "{{play_video_custom_icon_html|ucsafe|raw}}",		//custom videoplay icon html                
    video_closebutton_type: "{{close_button_type}}",
    video_closebutton_custom: "{{custom_close_button_icon_html|ucsafe|raw}}",                
    
    slider_enable_text_panel: {{slider_enable_text_panel}},			 
    slider_textpanel_always_on: {{text_panel_always_on}},			 
    slider_textpanel_text_valign:"middle",			
    slider_textpanel_padding_top:{{slider_textpanel_padding}},				 
    slider_textpanel_padding_bottom:{{slider_textpanel_padding}},			
    slider_textpanel_padding_right: {{slider_textpanel_padding}},			
    slider_textpanel_padding_left: {{slider_textpanel_padding}},			
    slider_textpanel_height: null,					
    slider_textpanel_padding_title_description: 5,	
    slider_textpanel_fade_duration: 200,			
    slider_textpanel_enable_title: {{slider_textpanel_enable_title}},			
    slider_textpanel_enable_description: true,		
    slider_textpanel_enable_bg: true,				
    slider_textpanel_bg_color:"{{slider_textpanel_bg_color}}",			
    slider_textpanel_bg_opacity: {{slider_textpanel_bg_opacity_nounit}}
  });

  {% if enable_lightbox == "true" %}

    var objItems = objGallery.find(".ug-slide-wrapper");	
    var strJson = {{put_items_json()}};
    var arrItems = JSON.parse(strJson);
	var imageItems = arrItems.map(item => {
        return {
            src: item.images.image,
            caption: item.images.title
        };
    });
	
    const fancyboxOptions = {
        loop: true,
        arrows : true,
        backfocus: false,
        btnTpl: {
          arrowLeft: `<button data-fancybox-prev class="fancybox-button fancybox-button--arrow_left" title="prev">` +
            `<div>{{previous_arrow_icon_html|ucsafe|raw}}</div>` +
            `</button>`,
          arrowRight: `<button data-fancybox-next class="fancybox-button fancybox-button--arrow_right" title="next">` +
            `<div>{{next_arrow_icon_html|ucsafe|raw}}</div>` +
            `</button>`,
          },
        {% if disable_zoom_in_after_lightbox_image_click == "true" %}
          clickContent: "next",
        {% endif %}     
    };

    objGallery.find('.ug-slider-wrapper').on('click', function(e) {
      var objTarget = jQuery(e.target);
      var objParentLink = objTarget.closest("a");

      if(objTarget.tagName == "A" || objParentLink && objParentLink.length > 0){
        var href = objTarget.attr("href") || objParentLink.attr("href");

        if(href == "#")
          e.preventDefault();
      }

      var selectedIndex = objGallery.data().unitegalleryApi.getNumCurrent();
	
      jQuery.fancybox.open(imageItems, {
          ...fancyboxOptions,
          index: selectedIndex
        });
    });

  {% endif %}

  {{ucfunc("put_remote_parent_js","objGallery","unitegallery")}}

  objGallery.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){      	
    api.changeItems(htmlItems);  
    
    if(!htmlItems)
        api.showMessageReplaceGallery("{{empty_message|ucsafe|raw}}"); 
  });  

{{ ucfunc("put_docready_end") }}