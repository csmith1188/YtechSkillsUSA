#{{uc_id}}{
  overflow:hidden;
}

#{{uc_id}}-wrapper{
  min-height:1px;
}

/* fancybox */
{% if enable_lightbox == "true" %}
  .fancybox-button,
  .fancybox-button svg path{	
    color: {{navigation_icons_color}};
    transition: all .3s ease;
  }
  .fancybox-button{
    background-color: {{navigation_icons_background_color}};
    transition: all .3s ease;
  }

  .fancybox-button:hover,
  .fancybox-button:hover svg path{	
    color: {{navigation_icons_color_hover}};
  }
  .fancybox-button:hover,
  .fancybox-button:focus{
    background-color: {{navigation_icons_background_color_hover}};
  }

  .fancybox-bg{
    background: {{overlay_background_color}};
  }

  .fancybox-is-open .fancybox-bg{
    opacity: {{overlay_opacity}} !important;
  }

  {% if show_lightbox_counter == "false" %}
    .fancybox-infobar{
      display: none !important;
    }
  {% endif %}	

  {% if show_lightbox_zoom_button == "false" %}
    .fancybox-button--zoom{
      display: none !important;
    }
  {% endif %}	

  {% if show_lightbox_slideshow_button == "false" %}
    .fancybox-button--play{
      display: none !important;
    }
  {% endif %}	

  {% if show_lightbox_thumbnails_button == "false" %}
    .fancybox-button--thumbs{
      display: none !important;
    }
  {% else %}	
    .fancybox-button--thumbs{
      display: inline-block !important;
    }
  {% endif %}

  {% if show_lightbox_close_button == "false" %}
    .fancybox-button--close{
      display: none !important;
    }
  {% endif %}	

  {% if show_lightbox_arrows == "false" %}
    .fancybox-navigation{
      display: none !important;
    }
  {% endif %}

  .fancybox-caption__body{
    color: {{item_title_in_lightbox_color}};
  }

{% endif %}
/* endfancybox */