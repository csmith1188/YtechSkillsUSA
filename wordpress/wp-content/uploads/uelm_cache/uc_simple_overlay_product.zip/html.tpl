<div class="uc_simple_overlay_product_box" id="{{uc_id}}">
    	  <img src="{{image}}"  alt=""/>
          <a href="{{link}}" {{link_html_attributes|raw}}>
          <div class="us_hover_box">
        	<div class="us_hover_inner_box">
                {% if show_title == "true" %}<p class="product-name">{{title|raw}}</p>{% endif %}	
                {% if show_rating == "true" %}<p class="ratings">{{put_items()}}</p>{% endif %}
                {% if show_price == "true" %}<p class="price-box">{{price|raw}}</p>{% endif %}
                {% if show_button == "true" %}<a href="{{link}}" class="uc_more_btn" {{link_html_attributes|raw}}>{{button_text|raw}}</a>{% endif %}
            </div>
        </div> 
        </a>
</div>