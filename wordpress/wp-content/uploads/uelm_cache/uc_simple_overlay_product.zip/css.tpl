#{{uc_id}} {

     text-align:center;
     position:relative;
     overflow:hidden;
}
#{{uc_id}} img{
     width:100%;
     object-fit: cover;
     display:block;
}
#{{uc_id}} .us_hover_box{
     width:100%;
     height:100%;
     opacity:{{overlay_opacity}};
     transition: all 0.3s ease-in-out 0s;
     height:100%;
     position: absolute;
     top:0px;
     left:0px;
}
 .uc_simple_overlay_product_box .us_hover_box .us_hover_inner_box{
     position:absolute;
     left:0px;
     width:100%;
     top: 50%;
     transform: translatey(-50%);
     transition: all 0.3s ease-in-out 0s;
}
.product-name {
     font-size: 21px;

}
 .uc_simple_overlay_product_box .us_hover_box .us_hover_inner_box .price-box {
   font-size:14px;
}
#{{uc_id}} .uc_more_btn{

  display:{{button_style}};
  text-align:center;
  text-decoration:none;
}

#{{uc_id}}:hover .us_hover_box{
     display:block;
     opacity:{{overlay_opacity_on_hover}};
}
 .uc_simple_overlay_product_box:hover .us_hover_inner_box{
     top:50%;
}