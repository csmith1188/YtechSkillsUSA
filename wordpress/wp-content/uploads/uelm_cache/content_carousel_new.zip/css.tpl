.ue-content-carousel{
  min-height:1px;
}

#{{uc_id}} .ue-item{
  transition:0.3s;
  position:relative;
}

#{{uc_id}} .carousel-image{
  transition:0.3s;
  background-position:center; 
  background-repeat:no-repeat;
}

#{{uc_id}} .uc_image_carousel_content-wrapper{
  width: 100%;
}

#{{uc_id}}{
  position:relative;
  min-height:1px;
}

#{{uc_id}} .ue-content-holder{
  display:flex;
  flex-direction:column;
}

#{{uc_id}} .ue-btn-holder{
  margin-top:auto;
}

{% if show_arrows == "true" %}
  #{{uc_id}} .owl-nav .owl-prev, #{{uc_id}} .owl-nav .owl-next{
    position:absolute;
    display:flex;
    align-items: center;
    justify-content: center;
    text-align:center;
    overflow:hidden;
  }
  #{{uc_id}} .owl-nav svg{
    width:1em;
    height:1em;
  }
  #{{uc_id}} .owl-nav .disabled{
    display: none;  
  }
{% endif %}

#{{uc_id}} .owl-dots {
overflow:hidden;
text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
border-radius:50%;
display:inline-block;
}

.uc_post_title{
  font-size:21px;
}

#{{uc_id}} .uc_image_carousel_container_holder{
  overflow:hidden;
}

#{{uc_id}} .uc_more_btn{  
    display:inline-block;
  text-decoration:none;
  text-align:center;
  transition:0.3s;
}


{% if layout == "overlay" %}
	#{{uc_id}} .uc_image_carousel_content    {
      position:absolute;
      top:0px;
      left:0px;
      bottom:0px;
      right:0px;
      opacity:0;
      transition:1s;
      display:flex;
      align-items:center;
      flex-direction:column;
      justify-content: center;
    }

	#{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
      opacity:1;
    }

{% endif %}

#{{uc_id}} .uc_date{
  color:gray;
  padding-top:10px;
  text-style:italic;
}

{% if layout == "partial_overlay" %}
	#{{uc_id}} .uc_image_carousel_content{
     position:absolute;
     bottom:{{content_spacing_nounit}}px;
     left:{{content_spacing_nounit}}px;
     right:{{content_spacing_nounit}}px;
    }
{% endif %}


{% if layout == "overlay_bottom" %}
	#{{uc_id}} .uc_image_carousel_content{
     position:absolute;
     bottom:0px;
     left:0px;
     right:0px;
    }
{% endif %}

{% if layout == "under_overlap" %}
	#{{uc_id}} .uc_image_carousel_content{
     margin-left:20px;
      margin-right:20px;
      margin-top:-30px;
      position:relative;
    }
{% endif %}

{% if layout == "reveal_from_bottom" %}
	#{{uc_id}} .uc_image_carousel_content{
        margin-left:0px;
        margin-right:0px;
        margin-top:0px;
        position:absolute;
      	bottom: -100%;
        left: 0;
        right: 0;
        transition: ease-in-out all 0.25s;
      	-webkit-transition: ease-in-out all 0.25s;
    }
    #{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
		bottom: 0;
    }
{% endif %}

#{{uc_id}} .ue-btn-inner-wrapper{
  display:inline-flex;
  align-items:center;
}

#{{uc_id}} .ue-btn-inner-wrapper svg{
  height:1em;
  width:1em;
}

#{{uc_id}} .uc_image_carousel_placeholder{
  position:relative;
}

#{{uc_id}} .ue_img_link{
  display:block;
  position:absolute;
  top:0px;
  right:0px;
  left:0px;
  bottom:0px;
}

/* start creative button hover styles */
#{{uc_id}} .uc_content{
  display: flex;
  flex-wrap: wrap;
}

/* GENERAL BUTTON STYLING */
#{{uc_id}} .uc_button {
  overflow:hidden;
}

#{{uc_id}} .uc_button,
#{{uc_id}} .uc_button::after {
	transition: all 0.3s;
}

#{{uc_id}} .uc_button {
  position: relative;
}

#{{uc_id}} .uc_button span{
  z-index: 2;
  position: relative;
  display: block;
}

#{{uc_id}} .uc_button::before,
#{{uc_id}} .uc_button::after {
  content: '';
  position: absolute;
  z-index: 1;
}

/* BUTTON 1 */
#{{uc_id}} .uc_btn-1::after {
  height: 0;
  left: 0;
  top: 0;
  width: 100%;
}

#{{uc_id}} .uc_btn-1:hover:after {
  height: 100%;
}

/* BUTTON 7 */
#{{uc_id}} .uc_btn-7::after {
  height: 0;
  left: 0;
  bottom: 0;
  width: 100%;
}

#{{uc_id}} .uc_btn-7:hover:after {
  height: 100%;
}

/* BUTTON 2 */
#{{uc_id}} .uc_btn-2::after {
  height: 100%;
  left: 0;
  top: 0;
  width: 0;
}

#{{uc_id}} .uc_btn-2:hover:after {
  width: 100%;
}

/* BUTTON 6 */
#{{uc_id}} .uc_btn-6::after {
  height: 100%;
  right: 0;
  top: 0;
  width: 0;
}

#{{uc_id}} .uc_btn-6:hover:after {
  width: 100%;
}

/* BUTTON 3 */
#{{uc_id}} .uc_btn-3::after {
  height: 0;
  left: 50%;
  top: 50%;
  width: 0;
}

#{{uc_id}} .uc_btn-3:hover:after {
  height: 100%;
  left: 0;
  top: 0;
  width: 100%;
}

/* BUTTON 4 */
#{{uc_id}} .uc_btn-4::before {
}

#{{uc_id}} .uc_btn-4::after {
  height: 100%;
  left: 0;
  top: 0;
  width: 100%;
}

#{{uc_id}} .uc_btn-4:hover:after{
  height: 0;
  left: 50%;
  top: 50%;
  width: 0;
}

/* BUTTON 5 */
#{{uc_id}} .uc_btn-5 {
  overflow: hidden;
}

#{{uc_id}} .uc_btn-5::after {
  height: 100%;
  left: -100%;
  top: 0;
  transform: skew(50deg);
  transition-duration: 0.6s;
  transform-origin: top left;
  width: 0;
}

#{{uc_id}} .uc_btn-5:hover:after {
  height: 100%;
  width: 200%;
}
/* end styles */