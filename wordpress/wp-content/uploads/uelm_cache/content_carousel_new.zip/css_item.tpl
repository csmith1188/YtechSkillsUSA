#{{item.item_id}} .carousel-image{
  background-image:url({{item.image}});
}