<div class="ue-content-carousel" >
  <div class="uc_carousel owl-carousel owl-theme uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" data-lightbox="{{link_type}}" data-equal-height="{{equalize_content_height}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
    {{put_items()}}
  </div>	
</div>